<?php

include 'connection.php';
$id = $_GET['id'];

if ($id){
    $stmt = $conn->prepare("DELETE FROM student WHERE student_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: index.php");
    exit();
}else{
    echo "Invalid request";
}

?>