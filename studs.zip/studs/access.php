<?php
session_start(); 

include 'connection.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $uzername = $_POST['uzername'];
    $pazzword = $_POST['pazzword'];

   
    $stmt = $conn->prepare("SELECT * FROM admins WHERE uzername = ? AND pazzword = ?");
    $stmt->bind_param("ss", $uzername, $pazzword);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['admin'] = $uzername; 
        header("Location: index.php"); 
        exit();
    } else {
        $error = "Invalid username or password."; 
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css"> 
    <title>Login</title>
</head>
<body>
<div class="form-container">
    <form method="POST" action="">
        <h2>Admin Login</h2>
        <input type="text" name="uzername" placeholder="Username" required>
        <input type="password" name="pazzword" placeholder="Password" required>
        <button type="submit">Login</button>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
    </form>
</div>
</body>
</html>
