<?php

session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: access.php"); 
    exit();
}


include 'connection.php'; 


$result = $conn->query("SELECT * FROM student");


if (isset($_GET['logout'])) {
    session_destroy(); 
    header("Location: access.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
    <title>Student Records</title>
</head>
<body>
<div class="container">
    <h1>Student Records</h1>
    <a href="insert.php" class="btn">Add Student</a>
    <a href="index.php?logout=true" class="btn">Logout</a>
    <table>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Program</th>
            <th>Year</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['student_id'] ?></td>
                <td><?= $row['firstname'] ?></td>
                <td><?= $row['lastname'] ?></td>
                <td><?= $row['program'] ?></td>
                <td><?= $row['year'] ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['student_id'] ?>" class="btn">Edit</a>
                    <a href="delete.php?id=<?= $row['student_id'] ?>" class="btn">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
