<?php
include 'connection.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM student WHERE student_id = $id");
$student = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $program = $_POST['program'];
    $year = $_POST['year'];

    $stmt = $conn->prepare("UPDATE student SET firstname = ?, lastname = ?, program = ?, year = ? WHERE student_id = ?");
    $stmt->bind_param("ssssi", $firstname, $lastname, $program, $year, $id);
    $stmt->execute();

    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
    <title>Edit Student</title>
</head>
<body>
<div class="form-container">
    <form method="POST" action="">
        <h2>Edit Student</h2>
        <input type="text" name="firstname" value="<?= $student['firstname'] ?>" required>
        <input type="text" name="lastname" value="<?= $student['lastname'] ?>" required>
        <input type="text" name="program" value="<?= $student['program'] ?>" required>
        <input type="text" name="year" value="<?= $student['year'] ?>" required>
        <button type="submit">Update</button>
    </form>
</div>
</body>
</html>
