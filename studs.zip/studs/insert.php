<?php

include 'connection.php';

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $program = $_POST['program'];
    $year = $_POST['year'];

    $stmt = $conn->prepare("INSERT INTO student (firstname, lastname, program, year) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss",$firstname,$lastname,$program,$year);
    $stmt->execute();

    header("Location: index.php");
    exit();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD STUDENT</title>
    <link rel="stylesheet" href="styles.css">

</head>
<body>
    <div class= "form-container">

    <form action="" method="POST">
        <h2>Add Student</h2>
        <input type="text" name= "firstname" placeholder="First Name" required>
        <input type="text" name= "lastname" placeholder="Last Name" required>
        <input type="text" name= "program" placeholder="Program" require>
        <input type="number" name= "year" placeholder="Year" required>
        <button type= submit>Add</button>

    </form>



    </div>
    
</body>
</html>